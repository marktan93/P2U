<?php

require_once 'core/settings.php';
require_once 'core/BarcodeQR.php';
require_once 'core/guzzle/autoload.php';

use GuzzleHttp\Client;

class P2U {
	
	private $uid, $points_id, $expired = false, $redeemed = false, $string;
	private $url = URL;
	
	
	public function set_points_id($points_id) {
		// check if expired or redeemed then do not allow to set the value
		
		// check redeemed
		$client = new Client();
		$response = $client->post($this->url.'check_redeemed', 
			array(
			'body' => array(
				'points_id' => $points_id
			)
		));
		$json = $response->json();
		if ($json['response'] == true) {
			$this->redeemed = $json['redeemed'];
		} 
		
		// check expired
		$response = $client->post($this->url.'check_expired', 
			array(
			'body' => array(
				'points_id' => $points_id
			)
		));
		$json = $response->json();
		if ($json['response'] == true) {
			$this->expired = $json['expired'];
		}
		
		if ($this->expired == false && $this->redeemed == false) 
			$this->points_id = $points_id;
	}
	
	public function get_points_id() {
		return $this->points_id;
	}
	
	// establish connection
	// return back uid
	public function establish() {
		$client = new Client();
		$response = $client->post($this->url.'establish', 
			array(
			'body' => array(
				'email' => EMAIL,
				'password' => PASSWORD
			)
		));
		
		$json = $response->json();
		if ($json['response'] == true) {
			$this->uid = $json["uid"];
		} else {
			die("P2U: Failed to establish the connection, please make sure the credentials is correct.");
		}
	}
	
	
	// send back the amount of purchase to P2U
	// P2U will insert new record and return back the info for generate QR code
	// after run generate should save the id to database
	public function generate($cost) {
		if (!empty($cost)) {
			$client = new Client();
			$response = $client->post($this->url.'generate', 
				array(
				'body' => array(
					'cost' => $cost,
					'uid' => $this->uid
				)
			));
			
			$json = $response->json();
			if ($json['response'] == true) {
				$this->points_id = intval($json['points_id']);
			} else {
				if ($json['message'] != null) { // not achieve minimum purchase
					$this->points_id = 0; // set points_id to error
				}
			}
		} else {
			die("P2U: Parameter error, cannot be empty and double or decimal data type only.");
		}
	}
	
	// get points information
	// return points as object
	public function info() {
		$client = new Client();
		$response = $client->post($this->url.'info', 
				array(
				'body' => array(
					'points_id' => intval($this->points_id)
				)
			));
		$json = $response->json();
		if ($json['response'] == true) {
			return $json['points'];
		} else {
			die("P2U: Failed to get the info from P2U.");
		}
	}
	
	// generate QRCODE
	// or image expired and redeemed
	public function QRCODE() {
		if ($this->expired == true)
			$this->string = "Expired";
		else if ($this->redeemed == true)
			$this->string = "Redeemed";
		else if ($this->points_id == 0)
			$this->string = "Buy+more";
		
		if ($this->redeemed == false && $this->expired == false && $this->points_id != 0) {
			$qr = new BarcodeQR(); 

			// create URL QR code 
			$qr->url($this->url.'points/'.intval($this->points_id)); 

			// display new QR code image 
			$qr->draw();
		} else {
			$url = 'http://placehold.it/150/09f/fff.png/&text='.$this->string;
			// execute the url
			// create a new cURL resource
			$ch = curl_init();

			// set URL and other appropriate options
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_HEADER, 0);

			// grab URL and pass it to the browser
			curl_exec($ch);

			// close cURL resource, and free up system resources
			curl_close($ch);
			
		}
	}
}

?>