<?php

if (!defined("EMAIL"))
	define("EMAIL", "Enter email");

if (!defined("PASSWORD"))
	define("PASSWORD", "Enter password");

// Important: Do not change the value of URL
if (!defined("URL"))
	define("URL", "http://www.7shocks.com/p2u/api/");

?>