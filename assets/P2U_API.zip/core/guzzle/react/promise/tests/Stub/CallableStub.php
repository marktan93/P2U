<?php

namespace React\Promise\Stub;

class CallableStub
{
    public function __invoke()
    {
    }
}
